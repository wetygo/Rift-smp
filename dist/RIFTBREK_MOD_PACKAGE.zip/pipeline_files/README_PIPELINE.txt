THE PIPELINE - region files (Minecraft Java 1.21.11). Full guide: THE_PIPELINE.md
  pipeline_hq_ithaca/region/     ring around the HQ + Ithaca (28 files; origin X 7680 Z 7680)
  pipeline_main_base__MERGE_ONLY/region/   ring around YOUR MAIN BASE (r.-4.0 and r.-4.1 hold your house: NEVER copy them over your world)
  MergeBase.java                 adds chunks into an existing world without losing yours (needs Java 21)

1. BACK UP your world, quit to the title screen.
2. Big ring: if none of the 28 file names exist in your region/ folder, copy the files in. Otherwise:
     java MergeBase.java "<world folder>" pipeline_hq_ithaca --dry-run     (then again without --dry-run)
3. Main-base ring - ALWAYS merge, dry run first:
     java MergeBase.java "<world folder>" pipeline_main_base__MERGE_ONLY --dry-run
   It stops and lists any chunk of yours that stands where the ring goes. Only add --replace-existing if you accept losing those chunks.
   (the folder holds region/ so pass the folder path, not region/)
4. Install the Fabric mod v1.0.6, then /rift verify pipeline and /rift verify mainwall (expect 7/7 each).
