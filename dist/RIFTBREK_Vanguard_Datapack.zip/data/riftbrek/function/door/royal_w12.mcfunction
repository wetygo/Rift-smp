# door tier 'royal' width 12: runs AT the command block; the power slot is the cell directly BELOW it (door lintel). Open = redstone_block, closed = iron_bars
execute positioned ~6 ~ ~ if entity @a[distance=..9,tag=rb_royal,tag=!rb_revoked,scores={rb_cred=1..,rb_clear=5..}] positioned ~-6 ~ ~ run fill ~ ~-1 ~ ~11 ~-1 ~ minecraft:redstone_block
execute positioned ~6 ~ ~ unless entity @a[distance=..9,tag=rb_royal,tag=!rb_revoked,scores={rb_cred=1..,rb_clear=5..}] positioned ~-6 ~ ~ run fill ~ ~-1 ~ ~11 ~-1 ~ minecraft:iron_bars
