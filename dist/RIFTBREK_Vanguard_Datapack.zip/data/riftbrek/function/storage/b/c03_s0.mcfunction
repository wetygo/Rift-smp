# hall b category 'shovels_hoes' slot 0
execute if items block ~ ~ ~1 container.0 #minecraft:shovels unless items block ~8 ~0 ~2 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:2,s:0}
execute if items block ~ ~ ~1 container.0 #minecraft:shovels unless items block ~8 ~0 ~4 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:4,s:0}
execute if items block ~ ~ ~1 container.0 #minecraft:shovels unless items block ~8 ~0 ~6 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:6,s:0}
execute if items block ~ ~ ~1 container.0 #minecraft:shovels unless items block ~8 ~0 ~8 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:8,s:0}
execute if items block ~ ~ ~1 container.0 #minecraft:hoes unless items block ~8 ~0 ~2 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:2,s:0}
execute if items block ~ ~ ~1 container.0 #minecraft:hoes unless items block ~8 ~0 ~4 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:4,s:0}
execute if items block ~ ~ ~1 container.0 #minecraft:hoes unless items block ~8 ~0 ~6 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:6,s:0}
execute if items block ~ ~ ~1 container.0 #minecraft:hoes unless items block ~8 ~0 ~8 container.0 * run function riftbrek:storage/move {dx:8,dy:0,dz:8,s:0}
