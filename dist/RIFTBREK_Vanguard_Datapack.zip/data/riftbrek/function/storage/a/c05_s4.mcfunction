# hall a category 'wool' slot 4
execute if items block ~ ~ ~1 container.4 #minecraft:wool unless items block ~12 ~0 ~2 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:2,s:4}
execute if items block ~ ~ ~1 container.4 #minecraft:wool unless items block ~12 ~0 ~4 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:4,s:4}
execute if items block ~ ~ ~1 container.4 #minecraft:wool unless items block ~12 ~0 ~6 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:6,s:4}
execute if items block ~ ~ ~1 container.4 #minecraft:wool unless items block ~12 ~0 ~8 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:8,s:4}
execute if items block ~ ~ ~1 container.4 #minecraft:wool_carpets unless items block ~12 ~0 ~2 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:2,s:4}
execute if items block ~ ~ ~1 container.4 #minecraft:wool_carpets unless items block ~12 ~0 ~4 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:4,s:4}
execute if items block ~ ~ ~1 container.4 #minecraft:wool_carpets unless items block ~12 ~0 ~6 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:6,s:4}
execute if items block ~ ~ ~1 container.4 #minecraft:wool_carpets unless items block ~12 ~0 ~8 container.4 * run function riftbrek:storage/move {dx:12,dy:0,dz:8,s:4}
