# macro: x,z = origin. Teleports YOU (as the executor) above the middle of zone 17 so its chunks are loaded around you.
$execute positioned $(x) 0 $(z) run tp @s ~127 150 ~639
