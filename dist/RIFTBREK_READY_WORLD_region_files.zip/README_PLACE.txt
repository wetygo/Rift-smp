RIFTBREK ready-made world files (Minecraft Java 1.21.11)
1. Create a NEW creative world (cheats on), world type Superflat -> preset 'The Void'. Quit to the title screen.
2. Select the world -> Edit -> Open World Folder.
3. Copy the folders 'region' and 'entities' from this zip INTO that world folder (replace if asked).
4. Copy RIFTBREK_Vanguard_Datapack.zip (NOT extracted) into the world's 'datapacks' folder.
5. Open the world, then:  /setworldspawn 383 32 740   and   /tp @s 383 33 740
6. /function riftbrek:paste/init
   /function riftbrek:admin/origin {x:0,z:0}
   /function riftbrek:admin/verify          (expect 9 x PASS)
World placement: schematic local (x,y,z) = world (x, y-64, z); origin = world X0 Z0.  Full guide: docs/PASTE_GUIDE.md
