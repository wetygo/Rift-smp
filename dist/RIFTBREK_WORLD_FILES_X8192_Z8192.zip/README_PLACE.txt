RIFTBREK base - region files (Minecraft Java 1.21.11), placed at X 8192, Z 8192
Footprint: X 8192..10111, Z 8192..8959, all heights.

1. BACK UP your world. Quit to the title screen.
2. In your world folder check these do NOT already exist:
     region/:   r.16.16 r.16.17 r.17.16 r.17.17 r.18.16 r.18.17 r.19.16 r.19.17
     entities/: r.18.17 r.19.16 r.19.17
   If none exist, copy the 'region' and 'entities' folders from this zip into your world folder.
   If any exist, do NOT copy - use MergeBase.java from the mod package (it merges without losing your chunks).
3. Install the Fabric mod (riftbrek-vanguard-1.0.4.jar + Fabric API) - it carries the data pack. Open the world.
4. /tp @s 8575 33 8932   then   /rift verify   (expect 9 / 9 PASS)
