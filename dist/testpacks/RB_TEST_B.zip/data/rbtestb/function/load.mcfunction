tellraw @a {"text":"[rbtestb] test pack RB_TEST_B LOADED","color":"green"}
