RIFTBREK HQ - ENLARGED (2304 x 1536) - region files, Minecraft Java 1.21.11
Footprint X 7808..10111, Z 7808..9343 (original base at X 8192 Z 8192 stays the origin for the data pack/mod) + the Pipeline wall X 7680..13327.
ONE merged set: original base + annex + outer ward + pipeline ring. 36 region files, 3 entity files.
1. BACK UP your world. Quit to the title screen.
2. If NONE of these exist in your world's region/ folder, copy region/ and entities/ from this zip into the world folder:
   r.15.15 r.15.16 r.15.17 r.15.18 r.16.15 r.16.16 r.16.17 r.16.18 r.17.15 r.17.16 r.17.17 r.17.18 r.18.15 r.18.16 r.18.17 r.18.18 r.19.15 r.19.16 r.19.17 r.19.18 r.20.15 r.20.18 r.21.15 r.21.18 r.22.15 r.22.18 r.23.15 r.23.18 r.24.15 r.24.18 r.25.15 r.25.18 r.26.15 r.26.16 r.26.17 r.26.18
   If any exist, do NOT copy - use MergeBase.java from the mod package (java MergeBase.java "<world>" base_files --dry-run first).
3. Install the Fabric mod (riftbrek-vanguard-1.0.7.jar + Fabric API), open the world, then:  /tp @s 8575 33 8932   /rift verify
