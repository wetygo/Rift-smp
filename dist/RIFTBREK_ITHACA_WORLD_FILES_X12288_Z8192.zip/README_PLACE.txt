ITHACA CITY - region files (Minecraft Java 1.21.11), placed at X 12288, Z 8192
Footprint X 12288..13055, Z 8192..8959, all heights. 4 files, no entity files.
1. BACK UP your world, quit to the title screen.
2. In your world's region/ folder check these do NOT exist: r.24.16 r.24.17 r.25.16 r.25.17
   If none exist, copy the 'region' folder from this zip into your world. If any exist, use MergeBase.java (mod package).
3. Install the Fabric mod (riftbrek-vanguard-1.0.5.jar + Fabric API). Open the world.
4. /tp @s 12672 33 8917   then   /rift verify city   (expect 9 / 9 PASS)
What is in it / what is not: docs/ITHACA_CITY.md in the mod package.
